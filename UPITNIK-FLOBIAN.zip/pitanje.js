const kviz = (function () {
	let odgovori = [];
	let rezultatiUpitnika = {};

	function Pitanje(tekst, ponudjeniOdgovori, slika, proizvod) {
		this.tekst = tekst;
		this.ponudjeniOdgovori = ponudjeniOdgovori;
		this.slika = slika;
		this.proizvod = proizvod;
	}

	let pitanja = [
		new Pitanje('1', ['DA', 'NE'], '1.png', 'flobian1'),
		new Pitanje('2', ['DA', 'NE'], '2.png', 'flobian2'),
		new Pitanje('3', ['DA', 'NE'], '3.png', 'flobian1'),
		new Pitanje('4', ['DA', 'NE'], '4.png', 'flobian2'),
		new Pitanje('5', ['DA', 'NE'], '5.png', 'flobian3'),
		new Pitanje('6', ['DA', 'NE'], '6.png', 'flobian3'),
		new Pitanje('7', ['DA', 'NE'], '7.png', 'flobian1'),
		new Pitanje('8', ['DA', 'NE'], '8.png', 'flobian4'),
		new Pitanje('9', ['DA', 'NE'], '9.png', 'flobian4'),
		new Pitanje('10', ['DA', 'NE'], '10.png', 'flobian1')
	]

	function Upitnik(pitanja) {
		this.pitanja = pitanja;
		this.RBPitanja = 0;
	}

	Upitnik.prototype.getPitanje = function () {
		return this.pitanja[this.RBPitanja];
	}
	Upitnik.prototype.isEnded = function () {
		return this.RBPitanja ===  this.pitanja.length;
	}

	function RezultatUpitnika(text, slika, proizvod) {
		this.text = text;
		this.slika = slika;
		this.proizvod = proizvod;
	}

	ponudjeniRezultati = {
		flobian1:	new RezultatUpitnika('bolovi u stomaku ...', 'bolovi.png', 'flobian1'),
		flobian2: new RezultatUpitnika('grcevi u stomaku ...', 'grcevi.png', 'flobian2'),
		flobian3: new RezultatUpitnika('gasovi u stomaku ...', 'gasovi.png', 'flobian3'),
		flobian4: new RezultatUpitnika('lom u stomaku ...', 'lom.png', 'flobian4')
	}

	return {
		odgovori,
		Upitnik,
		pitanja,
		ponudjeniRezultati
	}
})();



const kvizView = (function () {

	function prikaziRezultat(userOdgovori, ponudjeniRezultati) {
		let poljeRezultata = document.querySelector('#rezultat');
		let poljeUpitnika = document.querySelector('#upitnik');
		let savetiZaPrikazArr = [];
		console.log(ponudjeniRezultati)

		// obrisi polje upitnika posto je zavrsen
		poljeUpitnika.innerHTML = '';

		// iteracija odgovora korisnika i popunjavanje array-a pozitivnim odgovorima
		for (const obj of userOdgovori) {
			if (obj.odgovor === "DA") {		
				savetiZaPrikazArr.push(obj.proizvod);	
			}
		}

		let uniqueSavetiZaPrikazArr = [... new Set(savetiZaPrikazArr)];
		console.log(ponudjeniRezultati)

		// prikazi savet za taj problem 
		function prikaziSavet(ponudjeniRezultati) {
			let HTMLRezultat = '';

			for (var i = 0; i < uniqueSavetiZaPrikazArr.length; i++) {
				HTMLRezultat += "<H1>"+ponudjeniRezultati[`${uniqueSavetiZaPrikazArr[i]}`].text+"</H1>"
			}

			return HTMLRezultat;
		}

		poljeUpitnika.style = "display: none";
		poljeRezultata.style = "display: block";
		poljeRezultata.innerHTML = prikaziSavet(ponudjeniRezultati);
	
	}

	function prikaziPitanje(upitnik) {
		let poljeSlike = document.querySelector('.card-slika');
		let poljeTekstPitanja = document.querySelector('.card-pitanje');
		let poljeOdgovora = document.querySelector('.card-odgovori');
		

		// popuni sliku pitanja
		poljeSlike.innerHTML = `<img src="./img/${upitnik.pitanja[upitnik.RBPitanja].slika}" alt="">`

		// popuni tekst pitanja
		poljeTekstPitanja.innerHTML = `<H2>${upitnik.getPitanje().tekst}<H2>`;

		//prvo obrisi vec prikazane ponudjene odgovore
		poljeOdgovora.innerHTML = "";

		// popuni ponudjene odgovore
		upitnik.getPitanje().ponudjeniOdgovori.forEach(element => {
			let odgovorButton = document.createElement("button");

			odgovorButton.innerHTML = `${element}`;
			odgovorButton.dataset.button = 'odgovor';
			odgovorButton.dataset.odgovor = `${element}`;
			poljeOdgovora.appendChild(odgovorButton);
		});
	}

	return {
		prikaziPitanje,
		prikaziRezultat
	}
})();



const kvizController = (function () {
	let poljeOdgovora = document.querySelector('.card-odgovori');
	let poljeProgresa = document.querySelector('.progress-container');
	let upitnik = new kviz.Upitnik(kviz.pitanja);
	/* let ponudjeniRezultati = kviz.ponudjeniRezultati; */

	// event handlers
	poljeOdgovora.addEventListener('click', handleAnswerKlik); // napravi ovu callback funkciju 

	// on page load
	kvizView.prikaziPitanje(upitnik);
	

	function handleAnswerKlik() {
		
		const isAnswerButton = event.target.dataset.button === 'odgovor';
		const kliknutiOdgovor = event.target.dataset.odgovor;

		function pushAnswers() {
			// on click dopuni odgovori array sa pitanjem i odogovorom
			kviz.odgovori.push({
				pitanje: upitnik.getPitanje().tekst,
				odgovor: kliknutiOdgovor,
				proizvod: upitnik.getPitanje().proizvod
			})
		}

		//ako je kliknuto na odgovor
		if (isAnswerButton) {
				pushAnswers();
				// on click inkrementuj redni broj pitanja
				upitnik.RBPitanja++
				if (upitnik.isEnded()) {
					kvizView.prikaziRezultat(kviz.odgovori, kviz.ponudjeniRezultati); // prikazi stranu sa savetima za korisnika
				} else {
					kvizView.prikaziPitanje(upitnik);
				}	
		}
	}
	return {
		upitnik
	}
})(kviz, kvizView);






